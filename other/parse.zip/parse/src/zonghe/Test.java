package zonghe;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Properties;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


public class Test {
	private static String TXTPATH = "zonghe/1.txt" ;
	private static String XMLPATH = "zonghe/1.xml" ;
	private static String PROPERTIESPATH = "zonghe/1.properties" ;
	public static void main(String[] args) throws Exception{
		
		
		getTxtContent();
		
		getXmlContent();
		
		getPropertiesContent();
		
		calendar();
		
		
	}
	/**
	 * 解析XML
	 * @throws DocumentException
	 */
	@SuppressWarnings("unchecked")
	private static void getXmlContent() throws DocumentException {
		InputStream inputStream = Test.class.getClassLoader().getResourceAsStream(Test.XMLPATH) ;
		SAXReader reader = new SAXReader() ;
		Document document = reader.read(inputStream) ;
		Element element = document.getRootElement() ;
		System.out.println(element.getName());
		Iterator<Element> it = element.elementIterator();
		while (it.hasNext()) {
			Element name = it.next() ;
			System.out.println(name.elementText("name"));
		}
	}
	/**
	 * 解析 .Properties
	 * @throws IOException
	 */
	private static void getPropertiesContent() throws IOException {
		Properties properties = new Properties() ;
		InputStream inputStream = Test.class.getClassLoader().getResourceAsStream(Test.PROPERTIESPATH) ;
		properties.load(inputStream) ;
		System.out.println(properties.getProperty("ss"));
		System.out.println(properties.getProperty("hh"));
		System.out.println(properties.getProperty("ww"));
	}
	/**
	 * 解析.txt
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private static void getTxtContent() throws FileNotFoundException,
			IOException {
		
		InputStream inputStream = Test.class.getClassLoader().getResourceAsStream(Test.TXTPATH) ;
		byte[] b = null ;
		b = new byte[inputStream.available()];
		inputStream.read(b) ;
		String s3 = new String(b) ;
		System.out.println(s3);
	}
	/**
	 * 判断是否是每月最后一天
	 */
	private static void calendar() {
		Calendar calendar = Calendar.getInstance() ;
		String s = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime()) ;
		calendar.add(Calendar.DATE, -1) ;
		String s2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime()) ;
		
		System.out.println(s);
		System.out.println(s2);
		
		Calendar calendar2 = Calendar.getInstance() ;
		calendar2.set(Calendar.DAY_OF_MONTH, 30) ;
		Calendar calendar3 = (Calendar)calendar2.clone() ;
		
		calendar2.add(Calendar.DAY_OF_MONTH, 1) ;
		System.out.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar2.getTime()));
		System.out.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar3.getTime()));
		System.out.println(calendar2.get(Calendar.DAY_OF_MONTH)== calendar3.get(Calendar.DAY_OF_MONTH) );
	}

}
