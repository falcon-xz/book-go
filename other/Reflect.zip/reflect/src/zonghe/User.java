package zonghe;

public class User extends Base {

	private Integer age;

	private String age2 ;
	
	private Long age3 ;
	
	private boolean age4 ;
	
	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getUserInfo() {
		return this.age + "-" +this.age2 + "-" +this.age3 + "-" +this.age4 +"-"+this.account+ "-" +this.password  ;
	}

	public String getBaseAge(Base base) {
		return base.toString() + this.getAge();
	}

	public String getDefaultAge() {
		return "5";
	}

	public String getAge2() {
		return age2;
	}

	public void setAge2(String age2) {
		this.age2 = age2;
	}

	public Long getAge3() {
		return age3;
	}

	public void setAge3(Long age3) {
		this.age3 = age3;
	}

	public boolean isAge4() {
		return age4;
	}

	public void setAge4(boolean age4) {
		this.age4 = age4;
	}
	
	
	
}
