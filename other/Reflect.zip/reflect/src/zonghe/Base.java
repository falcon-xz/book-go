package zonghe;

import java.util.Map;

public class Base {
	public String account;
	public String password;

	public Base(Map<String, Object> map) {
		this.account = (String) map.get("account");
		this.password = (String) map.get("password");
	}

	public Base(String account, String password) {
		this.account = account;
		this.password = password;
	}

	public Base() {

	}

	public void init(Map<String, Object> map){
		this.account = (String) map.get("account");
		this.password = (String) map.get("password");
	}
	
	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBaseInfo() {
		String s = this.toString();
		return s;
	}

	@Override
	public String toString() {
		return "用户名：" + account + ";密码：" + password;
	}

}
