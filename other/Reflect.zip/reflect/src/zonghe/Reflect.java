package zonghe;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class Reflect {
	/** user对象路径 */
	public static String USERPATH = "zonghe.User" ;
	
	public static void main(String[] args) {
	
			
			try {
				fieldMethodReflect();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
			
			try {
				constructorReflect();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
			
			
	
		
	}
	/**
	 * 通过构造方法反射对象实例
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	@SuppressWarnings("rawtypes")
	private static void constructorReflect() throws ClassNotFoundException,
			InstantiationException, IllegalAccessException,
			InvocationTargetException {
		//反射类 
		Class cz = Class.forName(USERPATH) ;
		Class parentC = cz.getSuperclass() ;
		
		//获得实例
		int ii = 0 ;
		Constructor[] constructors = parentC.getConstructors() ;
		for (int i = 0; i < constructors.length; i++) {
			Constructor constructor = constructors[i] ;
			
			Class[] z = constructor.getParameterTypes() ;
			for (int j = 0; j < z.length; j++) {
				if("Map".equals(z[j].getSimpleName())){
					ii = i ;
				}
			}
		}
		//从父类的构造方法 获得实例
		Map<String, Object> map = new HashMap<String, Object>() ;
		map.put("account", "xingzhou") ;
		map.put("password", "123") ;
		Base base = (Base)constructors[ii].newInstance(map) ;
		System.out.println(base.toString());
	}
	/**
	 * 反射类 获得实例 并赋值
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static void fieldMethodReflect() throws ClassNotFoundException,
			InstantiationException, IllegalAccessException,
			NoSuchMethodException, InvocationTargetException {
		//反射类 
		Class cz = Class.forName(USERPATH) ;
		//获得实例
		Object object = cz.newInstance() ;
		Method method = cz.getDeclaredMethod("getDefaultAge") ;
		String s = (String) method.invoke(object) ;
		System.out.println(s);
		
		//反射字段
		Field[] field = cz.getDeclaredFields() ;
		for (int i = 0; i < field.length; i++) {
			Field f = field[i] ;
			String fieldName = f.getName() ;
			String fieldMethod = "" ;
			Method setFieldMethod = null ;
			//根据参数不同类型 反射不同对象 根据class 类型判断
			if(f.getType().getName().equals(Boolean.class.getName())){
				fieldMethod = "is"+fieldName.substring(0, 1).toUpperCase()+fieldName.substring(1,fieldName.length());
				setFieldMethod = cz.getDeclaredMethod(fieldMethod, Boolean.class) ;
				setFieldMethod.invoke(object, true) ;
			}else if (f.getType().getName().equals(String.class.getName())) {
				fieldMethod = "set"+fieldName.substring(0, 1).toUpperCase()+fieldName.substring(1,fieldName.length());
				setFieldMethod = cz.getDeclaredMethod(fieldMethod, String.class) ;
				setFieldMethod.invoke(object, "29") ;
			}else if (f.getType().getName().equals(Long.class.getName())) {
				fieldMethod = "set"+fieldName.substring(0, 1).toUpperCase()+fieldName.substring(1,fieldName.length());
				setFieldMethod = cz.getDeclaredMethod(fieldMethod, Long.class) ;
				setFieldMethod.invoke(object, 30l) ;
			}
			else if (f.getType().getName().equals(Integer.class.getName())) {
				fieldMethod = "set"+fieldName.substring(0, 1).toUpperCase()+fieldName.substring(1,fieldName.length());
				setFieldMethod = cz.getDeclaredMethod(fieldMethod, Integer.class) ;
				setFieldMethod.invoke(object, 28) ;
			}
		}
		//给父类初始化 init
		Class parentCz = cz.getSuperclass() ;
		method = parentCz.getDeclaredMethod("init",Map.class) ;
		Map<String, Object> map = new HashMap<String, Object>() ;
		map.put("account", "xingzhou") ;
		map.put("password", "123") ;
		method.invoke(object,map) ;
		
		//查看User的全部信息
		method = cz.getDeclaredMethod("getUserInfo") ;
		s = (String) method.invoke(object) ;
		System.out.println(s);
	}
}
